package main;

public class SharedRide extends EconomyRide {
    public int passengerCount;

    public SharedRide(int passengerCount, double pricePerMunite, String passengerName, String pickup, String destination, double distanceKm, int durationMin, double pricePerKm) {
        super(pricePerMunite, passengerName, pickup, destination, distanceKm, durationMin, pricePerKm);
        if (this.passengerCount <= 4 || this.passengerCount >= 1) {
            this.passengerCount = passengerCount;
        } else {
            System.out.println("please enter the value between 1 and 4");
            this.passengerCount = 1;
        }
    }

    @Override
    public double calculateFare() {
        return (super.calculateFare() / passengerCount) * 1.1;
    }

    @Override
    public String toString() {
        return "SharedRide{" + "passengerCount=" + passengerCount + '}';
    }
}