package main;

public class EconomyRide extends Ride {
    private double pricePerMunite;

    public EconomyRide(double pricePerMunite, String passengerName, String pickup, String destination, double distanceKm, int durationMin, double pricePerKm) {
        super(passengerName, pickup, destination, distanceKm, durationMin, pricePerKm);
        this.pricePerMunite = pricePerMunite;
    }

    public double getPricePerMunite() {
        return pricePerMunite;
    }

    @Override
    public double calculateFare() {
        if ((pricePerMunite * getDurationMin()) < 50) {
            return 50;
        } else {
            return super.calculateFare() + pricePerMunite * getDurationMin();
        }
    }

    @Override
    public String toString() {
        return "EconomyRide{" + "pricePerMunite=" + pricePerMunite + '}';
    }
}