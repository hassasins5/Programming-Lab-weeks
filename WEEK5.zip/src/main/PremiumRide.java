package main;

public class PremiumRide extends Ride {
    public double comfortFee;
    public double surgeMultiplier;

    public PremiumRide(double comfortFee, double surgeMultiplier, String passengerName, String pickup, String destination, double distanceKm, int durationMin, double pricePerKm) {
        super(passengerName, pickup, destination, distanceKm, durationMin, pricePerKm);
        this.comfortFee = comfortFee;
        if (this.surgeMultiplier <= 3.0 || this.surgeMultiplier >= 1.0) {
            this.surgeMultiplier = surgeMultiplier;
        } else {
            System.out.println("please enter the surgemultiplier value between 1 and 3");
            this.surgeMultiplier = 1.0;
        }
    }

    @Override
    public double calculateFare() {
        return (super.calculateFare() + comfortFee) * surgeMultiplier;
    }

    @Override
    public String toString() {
        return "PremiumRide{" + "comfortFee=" + comfortFee + ", surgeMultiplier=" + surgeMultiplier + '}';
    }
}