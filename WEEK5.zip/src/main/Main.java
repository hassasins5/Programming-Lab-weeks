package main;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Ride> list = new ArrayList<>();
        list.add(new Ride("hasan", "kızılay", "çankaya", 10, 10, 50));
        list.add(new Ride("hasan", "a", "b", 10, -10, 50));
        list.add(new EconomyRide(3, "bekir", "B", "erciyes", 10, 20, 10));
        list.add(new EconomyRide(3, "mustafa", "a", "erciyes", 10, 10, 20));
        list.add(new PremiumRide(3, 2, "abu", "G", "g", 10, 10, 10));
        list.add(new PremiumRide(3, 5, "zaloi", "m", "g", 10, 10, 10));
        list.add(new SharedRide(2, 3, "neyli", "kemalettin bulvarı", "ancaklı", 10, 10, 10));
        list.add(new SharedRide(10, 3, "neyli", "kemalettin bulvarı", "ancaklı", 10, 10, 10));
        
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).toString());
        }
    }
}