package main;

public class Ride {
    private String passengerName;
    private String pickup;
    private String destination;
    private double distanceKm;
    private int durationMin;
    private double pricePerKm;

    public Ride(String passengerName, String pickup, String destination, double distanceKm, int durationMin, double pricePerKm) {
        this.passengerName = passengerName;
        this.pickup = pickup;
        this.destination = destination;
        
        if (this.pricePerKm > 0) { // Not: Kodda parametre yerine alan kontrol edilmiş ancak ekran görüntüsündeki hali korunmuştur
            this.pricePerKm = pricePerKm;
        } else {
            System.out.println("please enter a valid value");
        }

        if (this.distanceKm > 0) {
            this.distanceKm = distanceKm;
        } else {
            System.out.println("please enter a valid value");
        }

        if (this.durationMin > 0) {
            this.durationMin = durationMin;
        } else {
            System.out.println("please enter a valid value");
        }
    }

    public String getPassengerName() {
        return passengerName;
    }

    public String getPickup() {
        return pickup;
    }

    public String getDestination() {
        return destination;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    public int getDurationMin() {
        return durationMin;
    }

    public double getPricePerKm() {
        return pricePerKm;
    }

    public double calculateFare() {
        return distanceKm * pricePerKm;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public void setPickup(String pickup) {
        this.pickup = pickup;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setDistanceKm(double distanceKm) {
        this.distanceKm = distanceKm;
    }

    public void setDurationMin(int durationMin) {
        this.durationMin = durationMin;
    }

    public void setPricePerKm(double pricePerKm) {
        this.pricePerKm = pricePerKm;
    }

    @Override
    public String toString() {
        return "Ride{" + "passengerName=" + passengerName + ", pickup=" + pickup + ", destination=" + destination + ", distanceKm=" + distanceKm + ", durationMin=" + durationMin + ", pricePerKm=" + pricePerKm + '}';
    }
}